﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class Form1 : Form
    {
        int qtdfilhos;
        char nome;
        double iprf, inss, salliq, salbruto, salfml;

        private void txtBruto_Validated(object sender, EventArgs e)
        {
            {
                errorSalBruto.SetError(txtBruto, "");

                if (!Double.TryParse(txtBruto.Text, out salbruto))
                {
                    errorSalBruto.SetError(txtBruto, "Valor inválido, tente novamente!");
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtBruto.Text, out salbruto))
            {
                MessageBox.Show("Preencha os campos de maneira correta!");

                txtBruto.Focus();
            }
            else
            {
                Double.TryParse(txtBruto.Text, out salbruto);
                int.TryParse(listFilhos.Text, out qtdfilhos);

                if (salbruto <= 800.47)
                {
                    txtAINSS.Text = "7,65%";
                    inss = 0.0765 * salbruto;
                }
                else if (salbruto <= 1050)
                {
                    txtAINSS.Text = "8,65%";
                    inss = 0.0865 * salbruto;
                }
                else if (salbruto <= 1400.17)
                {
                    txtAINSS.Text = "9,00%";
                    inss = 0.09 * salbruto;
                }
                else if (salbruto <= 2801.56)
                {
                    txtAINSS.Text = "11,00%";
                    inss = 0.11 * salbruto;
                }
                else
                {
                    txtAINSS.Text = "27,50%";
                    inss = 0.275 * salbruto;
                }

                if (salbruto <= 1257.12)
                {
                    txtAIPRF.Text = "Insento";
                    iprf = 0;
                }
                else if (salbruto <= 2512.08)
                {
                    txtAIPRF.Text = "15,00%";
                    iprf = 0.15 * salbruto;
                }
                else
                {
                    txtAIPRF.Text = "27,50%";
                    iprf = 0.275 * salbruto;
                }

                if (salbruto <= 435.32)
                {
                    salfml = qtdfilhos * 22.33;
                    txtSalFam.Text = txtSalFam.ToString();
                }
                else if (salbruto <= 654.61)
                {
                    salfml = qtdfilhos * 15.74;
                    txtSalFam.Text = salfml.ToString();
                }
                else
                {
                    txtSalFam.Text = "R$ 0,00";
                    salfml = 0;
                }

                txtDescINSS.Text = inss.ToString();
                txtDescIPRF.Text = iprf.ToString();

                salliq = salbruto + salfml - inss - iprf;
                txtSalLiq.Text = salliq.ToString();
            }
        }


    }
}
