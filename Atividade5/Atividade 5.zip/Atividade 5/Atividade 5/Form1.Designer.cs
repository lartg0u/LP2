﻿namespace Atividade_5
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listFilhos = new System.Windows.Forms.NumericUpDown();
            this.btnCalc = new System.Windows.Forms.Button();
            this.txtBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtDescIPRF = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.txtSalFam = new System.Windows.Forms.TextBox();
            this.txtAIPRF = new System.Windows.Forms.TextBox();
            this.txtAINSS = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lbldescirpf = new System.Windows.Forms.Label();
            this.lbldescinss = new System.Windows.Forms.Label();
            this.lblsalariol = new System.Windows.Forms.Label();
            this.lblsalariof = new System.Windows.Forms.Label();
            this.lblaliqirpf = new System.Windows.Forms.Label();
            this.lblaliqinss = new System.Windows.Forms.Label();
            this.lblfilhos = new System.Windows.Forms.Label();
            this.lblsalariob = new System.Windows.Forms.Label();
            this.lblnome = new System.Windows.Forms.Label();
            this.errorNome = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorSalBruto = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.listFilhos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorNome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorSalBruto)).BeginInit();
            this.SuspendLayout();
            // 
            // listFilhos
            // 
            this.listFilhos.Location = new System.Drawing.Point(173, 130);
            this.listFilhos.Name = "listFilhos";
            this.listFilhos.Size = new System.Drawing.Size(116, 20);
            this.listFilhos.TabIndex = 17;
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(339, 218);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(169, 43);
            this.btnCalc.TabIndex = 29;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // txtBruto
            // 
            this.txtBruto.Location = new System.Drawing.Point(173, 94);
            this.txtBruto.Mask = "00000.00";
            this.txtBruto.Name = "txtBruto";
            this.txtBruto.Size = new System.Drawing.Size(116, 20);
            this.txtBruto.TabIndex = 15;
            this.txtBruto.Validated += new System.EventHandler(this.txtBruto_Validated);
            // 
            // txtDescIPRF
            // 
            this.txtDescIPRF.Enabled = false;
            this.txtDescIPRF.Location = new System.Drawing.Point(173, 230);
            this.txtDescIPRF.Name = "txtDescIPRF";
            this.txtDescIPRF.ReadOnly = true;
            this.txtDescIPRF.Size = new System.Drawing.Size(116, 20);
            this.txtDescIPRF.TabIndex = 28;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(173, 186);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.ReadOnly = true;
            this.txtDescINSS.Size = new System.Drawing.Size(116, 20);
            this.txtDescINSS.TabIndex = 26;
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(431, 182);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.ReadOnly = true;
            this.txtSalLiq.Size = new System.Drawing.Size(116, 20);
            this.txtSalLiq.TabIndex = 24;
            // 
            // txtSalFam
            // 
            this.txtSalFam.Enabled = false;
            this.txtSalFam.Location = new System.Drawing.Point(431, 141);
            this.txtSalFam.Name = "txtSalFam";
            this.txtSalFam.ReadOnly = true;
            this.txtSalFam.Size = new System.Drawing.Size(116, 20);
            this.txtSalFam.TabIndex = 22;
            // 
            // txtAIPRF
            // 
            this.txtAIPRF.Enabled = false;
            this.txtAIPRF.Location = new System.Drawing.Point(431, 100);
            this.txtAIPRF.Name = "txtAIPRF";
            this.txtAIPRF.ReadOnly = true;
            this.txtAIPRF.Size = new System.Drawing.Size(116, 20);
            this.txtAIPRF.TabIndex = 20;
            // 
            // txtAINSS
            // 
            this.txtAINSS.Enabled = false;
            this.txtAINSS.Location = new System.Drawing.Point(431, 59);
            this.txtAINSS.Name = "txtAINSS";
            this.txtAINSS.ReadOnly = true;
            this.txtAINSS.Size = new System.Drawing.Size(116, 20);
            this.txtAINSS.TabIndex = 18;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(173, 59);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(116, 20);
            this.txtNome.TabIndex = 13;
            // 
            // lbldescirpf
            // 
            this.lbldescirpf.AutoSize = true;
            this.lbldescirpf.Location = new System.Drawing.Point(86, 233);
            this.lbldescirpf.Name = "lbldescirpf";
            this.lbldescirpf.Size = new System.Drawing.Size(31, 13);
            this.lbldescirpf.TabIndex = 27;
            this.lbldescirpf.Text = "IRPF";
            // 
            // lbldescinss
            // 
            this.lbldescinss.AutoSize = true;
            this.lbldescinss.Location = new System.Drawing.Point(86, 189);
            this.lbldescinss.Name = "lbldescinss";
            this.lbldescinss.Size = new System.Drawing.Size(32, 13);
            this.lbldescinss.TabIndex = 25;
            this.lbldescinss.Text = "INSS";
            // 
            // lblsalariol
            // 
            this.lblsalariol.AutoSize = true;
            this.lblsalariol.Location = new System.Drawing.Point(336, 185);
            this.lblsalariol.Name = "lblsalariol";
            this.lblsalariol.Size = new System.Drawing.Size(78, 13);
            this.lblsalariol.TabIndex = 23;
            this.lblsalariol.Text = "Salário Líquido";
            // 
            // lblsalariof
            // 
            this.lblsalariof.AutoSize = true;
            this.lblsalariof.Location = new System.Drawing.Point(335, 144);
            this.lblsalariof.Name = "lblsalariof";
            this.lblsalariof.Size = new System.Drawing.Size(76, 13);
            this.lblsalariof.TabIndex = 21;
            this.lblsalariof.Text = "Salário Família";
            // 
            // lblaliqirpf
            // 
            this.lblaliqirpf.AutoSize = true;
            this.lblaliqirpf.Location = new System.Drawing.Point(335, 103);
            this.lblaliqirpf.Name = "lblaliqirpf";
            this.lblaliqirpf.Size = new System.Drawing.Size(74, 13);
            this.lblaliqirpf.TabIndex = 19;
            this.lblaliqirpf.Text = "Alíquota IRPF";
            // 
            // lblaliqinss
            // 
            this.lblaliqinss.AutoSize = true;
            this.lblaliqinss.Location = new System.Drawing.Point(336, 62);
            this.lblaliqinss.Name = "lblaliqinss";
            this.lblaliqinss.Size = new System.Drawing.Size(75, 13);
            this.lblaliqinss.TabIndex = 16;
            this.lblaliqinss.Text = "Alíquota INSS";
            // 
            // lblfilhos
            // 
            this.lblfilhos.AutoSize = true;
            this.lblfilhos.Location = new System.Drawing.Point(77, 132);
            this.lblfilhos.Name = "lblfilhos";
            this.lblfilhos.Size = new System.Drawing.Size(86, 13);
            this.lblfilhos.TabIndex = 14;
            this.lblfilhos.Text = "Número de filhos";
            // 
            // lblsalariob
            // 
            this.lblsalariob.AutoSize = true;
            this.lblsalariob.Location = new System.Drawing.Point(77, 97);
            this.lblsalariob.Name = "lblsalariob";
            this.lblsalariob.Size = new System.Drawing.Size(66, 13);
            this.lblsalariob.TabIndex = 12;
            this.lblsalariob.Text = "Salário bruto";
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(77, 62);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(35, 13);
            this.lblnome.TabIndex = 11;
            this.lblnome.Text = "Nome";
            // 
            // errorNome
            // 
            this.errorNome.ContainerControl = this;
            // 
            // errorSalBruto
            // 
            this.errorSalBruto.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listFilhos);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.txtBruto);
            this.Controls.Add(this.txtDescIPRF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtSalFam);
            this.Controls.Add(this.txtAIPRF);
            this.Controls.Add(this.txtAINSS);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lbldescirpf);
            this.Controls.Add(this.lbldescinss);
            this.Controls.Add(this.lblsalariol);
            this.Controls.Add(this.lblsalariof);
            this.Controls.Add(this.lblaliqirpf);
            this.Controls.Add(this.lblaliqinss);
            this.Controls.Add(this.lblfilhos);
            this.Controls.Add(this.lblsalariob);
            this.Controls.Add(this.lblnome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.listFilhos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorNome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorSalBruto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown listFilhos;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.MaskedTextBox txtBruto;
        private System.Windows.Forms.TextBox txtDescIPRF;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.TextBox txtSalFam;
        private System.Windows.Forms.TextBox txtAIPRF;
        private System.Windows.Forms.TextBox txtAINSS;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lbldescirpf;
        private System.Windows.Forms.Label lbldescinss;
        private System.Windows.Forms.Label lblsalariol;
        private System.Windows.Forms.Label lblsalariof;
        private System.Windows.Forms.Label lblaliqirpf;
        private System.Windows.Forms.Label lblaliqinss;
        private System.Windows.Forms.Label lblfilhos;
        private System.Windows.Forms.Label lblsalariob;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.ErrorProvider errorNome;
        private System.Windows.Forms.ErrorProvider errorSalBruto;
    }
}

