﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_3_Louis
{
    public partial class Form1 : Form
    {
        double alt, peso, imc;

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso) || peso >= 300.00)
            {
                MessageBox.Show("Peso inválido!!!");
                txtPeso.Clear();
                txtPeso.Focus();
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(alt, 2);
            imc = Math.Round(imc, 1);
            txtIMC.Text = imc.ToString("N1");
            

            if (imc < 18.5)
                txtRes.Text = "Magreza";
            else
                if (imc <= 24.9)
                txtRes.Text = "Normal";
            else
                    if (imc <= 29.9)
                txtRes.Text = "Sobrepeso";
            else
                        if (imc <= 39.9)
                txtRes.Text = "Obesidade";
            else
                txtRes.Text = "Obesidade Agravada";
        }

        private void btnLimp_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAlt.Clear();
            txtRes.Clear();
            txtIMC.Clear();
            txtAlt.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtAlt_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAlt.Text, out alt) || alt >= 3.00)
            {
                MessageBox.Show("Altura inválida!!!");
                txtAlt.Clear();
                txtAlt.Focus();
            }
        }
    }
}
