﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos__Atividade_7_
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void BtnSorteio_Click(object sender, EventArgs e)
        {
            int num1, num2;


            if(!int.TryParse(txtNum1.Text, out num1) || !int.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("Dados inválidos!");
            }
            else
            {
                if((num1 <= 0) || (num2 <= 0) || (num1 >= num2))
                {
                    MessageBox.Show("O número 1 deve ser maior que o número 2");
                }
                else
                {
                    Random objR = new Random();
                    int aleatorio = objR.Next(num1, num2+1); //retorna numero randomico
                    MessageBox.Show($"O vencedor é o número: {aleatorio}");
                }
            }
        }
    }
}
