﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos__Atividade_7_
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void BtnContNum_Click(object sender, EventArgs e)
        {
            int cont = 0;

            for(var i=0; i<rchtxtFrase.Text.Length; i++)
            {
                if(Char.IsNumber(rchtxtFrase.Text[i]))
                {
                    cont++;
                }
            }
            MessageBox.Show("A frase contém "+cont+" números!");
        }

        private void BtnPosi1_Click(object sender, EventArgs e)
        {
            int cont = 0;
            int posicao = 0;

            while(cont < rchtxtFrase.Text.Length)
            {
                if(char.IsWhiteSpace(rchtxtFrase.Text[cont]))
                {
                    posicao = cont + 1;
                    break;
                }
                cont++;
            }
            MessageBox.Show($"A posição do primeiro caracter em branco é: {posicao}");
        }

        private void BtnContL_Click(object sender, EventArgs e)
        {
            int cont = 0;

            foreach(var c in rchtxtFrase.Text)
            {
                if(char.IsLetter(c))
                {
                    cont += 1;
                }
            }
            MessageBox.Show($"A frase tem: {cont} letras");
        }
    }
}
