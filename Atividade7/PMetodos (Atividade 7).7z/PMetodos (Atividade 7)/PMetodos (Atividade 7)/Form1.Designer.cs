﻿namespace PMetodos__Atividade_7_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnStrp1 = new System.Windows.Forms.MenuStrip();
            this.exercício1 = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarCtrlCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colarCtrlCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercício2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exercício3 = new System.Windows.Forms.ToolStripMenuItem();
            this.exercício4 = new System.Windows.Forms.ToolStripMenuItem();
            this.exercício5 = new System.Windows.Forms.ToolStripMenuItem();
            this.sair = new System.Windows.Forms.ToolStripMenuItem();
            this.mnStrp1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnStrp1
            // 
            this.mnStrp1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.mnStrp1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exercício1,
            this.exercício2,
            this.exercício3,
            this.exercício4,
            this.exercício5,
            this.sair});
            this.mnStrp1.Location = new System.Drawing.Point(0, 0);
            this.mnStrp1.Name = "mnStrp1";
            this.mnStrp1.Size = new System.Drawing.Size(1165, 33);
            this.mnStrp1.TabIndex = 0;
            this.mnStrp1.Text = "Exercício&1";
            // 
            // exercício1
            // 
            this.exercício1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiarCtrlCToolStripMenuItem,
            this.colarCtrlCToolStripMenuItem});
            this.exercício1.Name = "exercício1";
            this.exercício1.Size = new System.Drawing.Size(101, 29);
            this.exercício1.Text = "Exercício&1";
            // 
            // copiarCtrlCToolStripMenuItem
            // 
            this.copiarCtrlCToolStripMenuItem.Name = "copiarCtrlCToolStripMenuItem";
            this.copiarCtrlCToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copiarCtrlCToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.copiarCtrlCToolStripMenuItem.Text = "Copiar";
            this.copiarCtrlCToolStripMenuItem.Click += new System.EventHandler(this.CopiarCtrlCToolStripMenuItem_Click);
            // 
            // colarCtrlCToolStripMenuItem
            // 
            this.colarCtrlCToolStripMenuItem.Name = "colarCtrlCToolStripMenuItem";
            this.colarCtrlCToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.colarCtrlCToolStripMenuItem.Size = new System.Drawing.Size(210, 30);
            this.colarCtrlCToolStripMenuItem.Text = "Colar";
            this.colarCtrlCToolStripMenuItem.Click += new System.EventHandler(this.ColarCtrlCToolStripMenuItem_Click);
            // 
            // exercício2
            // 
            this.exercício2.Name = "exercício2";
            this.exercício2.Size = new System.Drawing.Size(101, 29);
            this.exercício2.Text = "Exercício&2";
            this.exercício2.Click += new System.EventHandler(this.Exercício2_Click_1);
            // 
            // exercício3
            // 
            this.exercício3.Name = "exercício3";
            this.exercício3.Size = new System.Drawing.Size(101, 29);
            this.exercício3.Text = "Exercício&3";
            this.exercício3.Click += new System.EventHandler(this.Exercício3_Click);
            // 
            // exercício4
            // 
            this.exercício4.Name = "exercício4";
            this.exercício4.Size = new System.Drawing.Size(101, 29);
            this.exercício4.Text = "Exercício&4";
            this.exercício4.Click += new System.EventHandler(this.Exercício4_Click);
            // 
            // exercício5
            // 
            this.exercício5.Name = "exercício5";
            this.exercício5.Size = new System.Drawing.Size(101, 29);
            this.exercício5.Text = "Exercício&5";
            this.exercício5.Click += new System.EventHandler(this.Exercício5_Click);
            // 
            // sair
            // 
            this.sair.Name = "sair";
            this.sair.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.sair.Size = new System.Drawing.Size(53, 29);
            this.sair.Text = "&Sair";
            this.sair.Click += new System.EventHandler(this.Sair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1165, 635);
            this.Controls.Add(this.mnStrp1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.mnStrp1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.mnStrp1.ResumeLayout(false);
            this.mnStrp1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnStrp1;
        private System.Windows.Forms.ToolStripMenuItem exercício1;
        private System.Windows.Forms.ToolStripMenuItem exercício2;
        private System.Windows.Forms.ToolStripMenuItem exercício3;
        private System.Windows.Forms.ToolStripMenuItem exercício4;
        private System.Windows.Forms.ToolStripMenuItem exercício5;
        private System.Windows.Forms.ToolStripMenuItem sair;
        private System.Windows.Forms.ToolStripMenuItem copiarCtrlCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colarCtrlCToolStripMenuItem;
    }
}

