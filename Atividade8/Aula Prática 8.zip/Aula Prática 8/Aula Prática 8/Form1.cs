﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Aula_Prática_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um número {i+1}", "Entrada de Dados");

                if (auxiliar == "")
                    return;

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);
            //reverse
           // Array.Reverse(vetor);

            //auxiliar = "";
            //foreach (var x in vetor)
              //  auxiliar += x + "\n";
            //MessageBox.Show(auxiliar);
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            double[,] medias = new double[20, 3];
            double operacao =0;
            string entrada = "";
            string saida = "";

            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    entrada = Interaction.InputBox($"Para o {aluno + 1}° aluno, digite a {nota + 1}° nota.");


                    if (!double.TryParse(entrada, out medias[aluno, nota]) || medias[aluno, nota] < 0 || medias[aluno, nota] > 10)
                    {
                        MessageBox.Show("Valor inválido");
                        nota--;
                    }
                    else
                    {
                        operacao += medias[aluno, nota];
                        if (nota == 2)
                        {
                            operacao = operacao / 3;
                            saida = saida + $"Aluno n° {aluno + 1} / Média: {operacao}" + "+\n";

                        }
                    }
                }
                operacao = 0;
                MessageBox.Show(saida);
            }
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "Andre", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for (I = 0; I < N - 1; I++)
                Total += Alunos[I].Length;
            MessageBox.Show("Podemos concluir que o total vale: " + Total.ToString());
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            ArrayList ListaAlunos = new ArrayList();
            string auxiliar;

            ListaAlunos.Add("Ana");
            ListaAlunos.Add("André");
            ListaAlunos.Add("Débora");
            ListaAlunos.Add("Fátima");
            ListaAlunos.Add("João");
            ListaAlunos.Add("Janete");
            ListaAlunos.Add("Otávio");
            ListaAlunos.Add("Marcelo");
            ListaAlunos.Add("Pedro");
            ListaAlunos.Add("Thais");

            auxiliar = "Incluindo o Otávio:" + "\n\n";
            foreach (var x in ListaAlunos)
                auxiliar += x.ToString() + "\n";
            MessageBox.Show(auxiliar, "Lista sem a remoção");


            ListaAlunos.Remove("Otávio");

            auxiliar = "Não incluindo o Otávio:" + "\n\n";
            foreach (var x in ListaAlunos)
                auxiliar += x.ToString() + "\n";
            MessageBox.Show(auxiliar, "Lista com a remoção");
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            string[] Nomes = new string[8];
            int[] Tamanho = new int[8];
            string aux = "";
            string resultado = "";

            for (var x = 0; x < 8; x++)
            {
                aux = "";
                aux = Interaction.InputBox("Digite o nome da pessoa:", "Pessoas");
                Nomes[x] = aux;
            }
            for (var cont1 = 0; cont1 < 8; cont1++)
            {
                int cont2 = 0;
                foreach (var cont3 in Nomes[cont1])
                    if (cont3 == ' ')
                        cont2++;
                Tamanho[cont1] = Nomes[cont1].Length - cont2;
            }
            for (var cont4 = 0; cont4 < 8; cont4++)
               resultado += ($"O nome {Nomes[cont4]} tem {Tamanho[cont4]} caracteres" + "\n\n");
               MessageBox.Show(resultado);
        }
    }
    }

