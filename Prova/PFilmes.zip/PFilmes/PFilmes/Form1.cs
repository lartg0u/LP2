﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilmes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExec_Click(object sender, EventArgs e)
        {

            string aux = "";
            string saida = "";
            int cont, cont2;
            double[,] notas = new double[2, 8];
            double media1 = 0;
            double media2 = 0;
            double operacao = 0;


            for (cont = 0; cont < 2; cont++)
            {
                for (cont2 = 0; cont2 < 8; cont2++)
                {
                    aux = Interaction.InputBox($"Digite a nota para o {cont+1}° filme: ");
                    if (!double.TryParse(aux, out notas[cont, cont2]) || notas[cont, cont2] < 0 || notas[cont, cont2] > 10)
                    {
                        MessageBox.Show("Nota inválida, tente novamente!");
                        cont2--;
                    }
                    else
                    { 
                        saida = saida + "\n" + $"Pessoa {cont2} - Nota filme 1: {notas[0, cont2]} / Nota filme 2: {notas[1, cont2]}";
                    

                        operacao += notas[cont, cont2];
                        if (cont == 0 && cont2 == 7)
                        {
                            media1 = operacao / 8;
                        }
                        else
                            if (cont == 1 && cont2 == 7)
                        {
                            media2 = operacao / 8;
                        }
                    }
                }
                operacao = 0;
            }
            saida = saida + $"\n\n----------------------------------------------------------\n\nMédia filme 1: {media1}\nMédia filme 2: {media2}";
            MessageBox.Show(saida);
        }
    }
}
