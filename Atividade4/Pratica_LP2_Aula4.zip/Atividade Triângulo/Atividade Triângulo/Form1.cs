﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_Triângulo
{
    public partial class Form1 : Form
    {
        double ld1, ld2, ld3;

        private void TxtLd2_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtLd2, "");

            if (!double.TryParse(txtLd2.Text, out ld2) || ld2 <= 0)
            {
                errorProvider1.SetError(txtLd2, "Valor de B é inválido!");
                txtLd2.Focus();
            }
        }

        private void TxtLd3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtLd3, "");

            if (!double.TryParse(txtLd3.Text, out ld3) || ld3 <= 0)
            {
                errorProvider1.SetError(txtLd3, "Valor de C é inválido!");
                txtLd3.Focus();
            }
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            if (ld1 < (ld2 + ld3) && ld1 >
                Math.Abs(ld2 - ld3) && ld2 < (ld1 + ld3)
                && ld2 > Math.Abs(ld1 - ld3)
                && ld3 < (ld1 + ld2) &&
                ld3 > Math.Abs(ld1 - ld2))
            {
                if ((ld1 + ld2 + ld3) / 3 == ld1)
                    txtRes.Text = "Equilátero";
                else
                    if (ld1 != ld2 && ld2 != ld3 && ld3 != ld1)
                    txtRes.Text = "Escaleno";
                else
                    txtRes.Text = "Isóceles";

            }
            else
                txtRes.Text = "Não é triângulo!";
        }

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            txtLd1.Clear();
            txtLd2.Clear();
            txtLd3.Clear();
            txtLd1.Focus();
            errorProvider1.SetError(txtLd1, "");
            errorProvider2.SetError(txtLd2, "");
            errorProvider3.SetError(txtLd3, "");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void TxtLd1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtLd1, "");

            if(!double.TryParse(txtLd1.Text, out ld1) || ld1 <= 0)
            {
                errorProvider1.SetError(txtLd1, "Valor de A é inválido!");
                txtLd1.Focus();
            }
        }
    }
}
