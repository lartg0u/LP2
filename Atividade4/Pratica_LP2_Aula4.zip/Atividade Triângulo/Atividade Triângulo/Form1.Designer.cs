﻿namespace Atividade_Triângulo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtLd1 = new System.Windows.Forms.TextBox();
            this.txtLd2 = new System.Windows.Forms.TextBox();
            this.txtLd3 = new System.Windows.Forms.TextBox();
            this.lblLd1 = new System.Windows.Forms.Label();
            this.lblLd2 = new System.Windows.Forms.Label();
            this.lblLd3 = new System.Windows.Forms.Label();
            this.btnLimp = new System.Windows.Forms.Button();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.lblRes = new System.Windows.Forms.Label();
            this.txtRes = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            this.SuspendLayout();
            // 
            // txtLd1
            // 
            this.txtLd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLd1.Location = new System.Drawing.Point(315, 123);
            this.txtLd1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtLd1.Name = "txtLd1";
            this.txtLd1.Size = new System.Drawing.Size(233, 32);
            this.txtLd1.TabIndex = 0;
            this.txtLd1.Validated += new System.EventHandler(this.TxtLd1_Validated);
            // 
            // txtLd2
            // 
            this.txtLd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLd2.Location = new System.Drawing.Point(315, 161);
            this.txtLd2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtLd2.Name = "txtLd2";
            this.txtLd2.Size = new System.Drawing.Size(233, 32);
            this.txtLd2.TabIndex = 1;
            this.txtLd2.Validated += new System.EventHandler(this.TxtLd2_Validated);
            // 
            // txtLd3
            // 
            this.txtLd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLd3.Location = new System.Drawing.Point(315, 200);
            this.txtLd3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtLd3.Name = "txtLd3";
            this.txtLd3.Size = new System.Drawing.Size(233, 32);
            this.txtLd3.TabIndex = 2;
            this.txtLd3.Validated += new System.EventHandler(this.TxtLd3_Validated);
            // 
            // lblLd1
            // 
            this.lblLd1.AutoSize = true;
            this.lblLd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLd1.Location = new System.Drawing.Point(195, 123);
            this.lblLd1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLd1.Name = "lblLd1";
            this.lblLd1.Size = new System.Drawing.Size(78, 26);
            this.lblLd1.TabIndex = 3;
            this.lblLd1.Text = "Lado 1";
            // 
            // lblLd2
            // 
            this.lblLd2.AutoSize = true;
            this.lblLd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLd2.Location = new System.Drawing.Point(195, 161);
            this.lblLd2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLd2.Name = "lblLd2";
            this.lblLd2.Size = new System.Drawing.Size(78, 26);
            this.lblLd2.TabIndex = 4;
            this.lblLd2.Text = "Lado 2";
            // 
            // lblLd3
            // 
            this.lblLd3.AutoSize = true;
            this.lblLd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLd3.Location = new System.Drawing.Point(195, 200);
            this.lblLd3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLd3.Name = "lblLd3";
            this.lblLd3.Size = new System.Drawing.Size(78, 26);
            this.lblLd3.TabIndex = 5;
            this.lblLd3.Text = "Lado 3";
            // 
            // btnLimp
            // 
            this.btnLimp.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimp.Location = new System.Drawing.Point(193, 300);
            this.btnLimp.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLimp.Name = "btnLimp";
            this.btnLimp.Size = new System.Drawing.Size(105, 51);
            this.btnLimp.TabIndex = 6;
            this.btnLimp.Text = "Limpar";
            this.btnLimp.UseVisualStyleBackColor = true;
            this.btnLimp.Click += new System.EventHandler(this.BtnLimp_Click);
            // 
            // btnCalc
            // 
            this.btnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(309, 300);
            this.btnCalc.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(113, 51);
            this.btnCalc.TabIndex = 7;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(433, 300);
            this.btnSair.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(105, 51);
            this.btnSair.TabIndex = 8;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblRes
            // 
            this.lblRes.AutoSize = true;
            this.lblRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRes.Location = new System.Drawing.Point(181, 240);
            this.lblRes.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRes.Name = "lblRes";
            this.lblRes.Size = new System.Drawing.Size(110, 26);
            this.lblRes.TabIndex = 9;
            this.lblRes.Text = "Resultado";
            // 
            // txtRes
            // 
            this.txtRes.Enabled = false;
            this.txtRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRes.Location = new System.Drawing.Point(315, 240);
            this.txtRes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtRes.Name = "txtRes";
            this.txtRes.Size = new System.Drawing.Size(233, 32);
            this.txtRes.TabIndex = 10;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(714, 422);
            this.Controls.Add(this.txtRes);
            this.Controls.Add(this.lblRes);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.btnLimp);
            this.Controls.Add(this.lblLd3);
            this.Controls.Add(this.lblLd2);
            this.Controls.Add(this.lblLd1);
            this.Controls.Add(this.txtLd3);
            this.Controls.Add(this.txtLd2);
            this.Controls.Add(this.txtLd1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLd1;
        private System.Windows.Forms.TextBox txtLd2;
        private System.Windows.Forms.TextBox txtLd3;
        private System.Windows.Forms.Label lblLd1;
        private System.Windows.Forms.Label lblLd2;
        private System.Windows.Forms.Label lblLd3;
        private System.Windows.Forms.Button btnLimp;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label lblRes;
        private System.Windows.Forms.TextBox txtRes;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
    }
}

